Screw head type instance segmentation: data for a course homework.

Source   : "Screw classification" by project-s0l2s on Roboflow Universe, version 4 (2025-12-16)
           https://universe.roboflow.com/project-s0l2s/screw-classification-tcn4h/dataset/4
License  : CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/) as published by the project.
           The wood-board photographs appear to come from MVTec Screws
           (https://www.mvtec.com/company/research/datasets/mvtec-screws), released under
           CC BY-NC-SA 4.0: use this archive for non-commercial purposes only, give credit,
           and share any adaptation under the same licence.
Changes  : the images are resized to a long side of 800 pixels, saved as JPEG and renamed;
           the labels of most training images are removed; labels drawn as boxes are replaced by polygons.
Classes  : 0 button_head, 1 flat_head, 2 pan_head
Labels   : one text file per image, one line per screw: class x1 y1 x2 y2 ... (a polygon, fractions of the image size)
Folders  : labelled (50 training images with labels), unlabelled (450 training images, no labels),
           test (100 images with labels; the valid split of the source)
